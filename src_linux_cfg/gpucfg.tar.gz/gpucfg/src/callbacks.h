#include <gtk/gtk.h>


void
on_btnSave_clicked                     (GtkButton       *button,
                                        gpointer         user_data);



void
on_CfgWnd_destroy                      (GtkObject       *object,
                                        gpointer         user_data);

void
on_btnCancel_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_AboutWnd_destroy                    (GtkObject       *object,
                                        gpointer         user_data);

void
on_bntAClose_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
